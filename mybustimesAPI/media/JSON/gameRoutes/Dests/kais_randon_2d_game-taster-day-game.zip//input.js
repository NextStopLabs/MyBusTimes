var input = {};

/**
 * Sets up player input, namely WASD + Space
 * @param {*} scene The scene
 */
input.setupWASD = (scene) =>
{
    //Show debug
    utils.debug.print("Setting up player input");

    //Just use addKeys
    input.keys = scene.input.keyboard.addKeys("W,A,S,D,SPACE,E");
}

/**
 * Checks if the player has just pressed the jump key
 * @returns true/false
 */
input.jump = () => Phaser.Input.Keyboard.JustDown(input.keys.W) || Phaser.Input.Keyboard.JustDown(input.keys.SPACE);


/**
 * Checks if the player is holding down the attack key
 * @returns true/false
 */
input.attack = () => input.keys.E.isDown;


/**
 * Checks if the player is holding down the move right key
 * @returns true/false
 */
input.moveRight = () => input.keys.D.isDown;


/**
 * Checks if the player is holding down the move left key
 * @returns true/false
 */
input.moveLeft = () => input.keys.A.isDown;


/**
 * Checks if the player is holding down the move down key
 * @returns true/false
 */
input.moveDown = () => input.keys.S.isDown;