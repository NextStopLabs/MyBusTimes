
const tilemap = {
    baseTileImage: null,
    showDebug: true,
    scale: 1.5
}

const layers = {

}


tilemap.preloadTiles = (scene, basePath) => 
{
    //Load the actual tileset
    tilemap.baseTileImage = scene.load.image("tilesetImage", `${basePath}/tilesetMk2.png`);
    utils.debug.printResult("Loaded base tileset image.", tilemap.showDebug);

    //Load exit
    scene.load.spritesheet("exit", `${basePath}/exit.png`, utils.game.frameWH(32, 32));

    //Load the tilemap
    scene.load.tilemapTiledJSON("tilemapData", `${basePath}/level1.json`);
    utils.debug.printResult("Loaded tilemap", tilemap.showDebug);
}

tilemap.createTiles = (scene) =>
{
    //Create the tilemap & tilesets
    tilemap.map = scene.make.tilemap({ key: "tilemapData" });
    tilemap.tileset = tilemap.map.addTilesetImage("mk2Tiles", "tilesetImage", 16, 16);

    //Make layer
    layers.sky = tilemap.map.createLayer("sky", tilemap.tileset).setScale(tilemap.scale).setDepth(-7).setScrollFactor(1.1, 1);
    layers.caveBackground = tilemap.map.createLayer("cave-background", tilemap.tileset).setScale(tilemap.scale).setDepth(-6);
    layers.background = tilemap.map.createLayer("background", tilemap.tileset).setScale(tilemap.scale).setDepth(-5);
    layers.foreground = tilemap.map.createLayer("foreground", tilemap.tileset).setScale(tilemap.scale).setDepth(-1);
    layers.decoration = tilemap.map.createLayer("decoration", tilemap.tileset).setScale(tilemap.scale).setDepth(0);
    layers.coins = tilemap.map.createLayer("coins", tilemap.tileset).setScale(tilemap.scale);
    layers.breakables = tilemap.map.createLayer("breakables", tilemap.tileset).setScale(tilemap.scale).setDepth(1);

    layers.coins.visible = false;


    //Create collision
    layers.foreground.setCollisionByExclusion(-1, true);
    layers.coins.setCollisionByExclusion(-1, true);
    layers.breakables.setCollisionByExclusion(-1, true);

    /*
    //Set scale
    layers.sky.setScale(2).setScrollFactor(0.6, 1.0);
    layers.ground.setScale(2).setDepth(1);
    layers.decoration.setScale(2).setDepth(1);
    layers.water.setScale(2).setDepth(5).setScrollFactor(0.99, 1);
    layers.breakables.setScale(2).setDepth(1);
    layers.collectables.setScale(2).setDepth(3);
    */
}