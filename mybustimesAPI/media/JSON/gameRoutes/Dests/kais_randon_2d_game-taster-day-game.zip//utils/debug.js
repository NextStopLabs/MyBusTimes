utils.debug = 
{
    /**
     * Retrieves the time for logging purposes.
     * @returns The time, in short format
     */
    time: () => new Date().toLocaleTimeString(),

    /**
     * Prints output, given any object 
     * @param {*} obj 
     */
    print: (obj, condition=true) => 
    {
        if(!condition) return;
        console.log(`[${utils.debug.time()}] ${obj}`)
    },

    /**
     * Prints output, formatted as a result, given any object
     * @param {*} obj 
     */
    printResult: (obj, condition=true) => 
    {
        if(!condition) return;
        console.log(`[${utils.debug.time()}] >> ${obj}`)
    },

    /**
     * Alias for console.group
     */
    group: (name) => console.group(name),

    /**
     * Alias for console.groupEnd
     */
    groupEnd: (name) => console.groupEnd(name),
}