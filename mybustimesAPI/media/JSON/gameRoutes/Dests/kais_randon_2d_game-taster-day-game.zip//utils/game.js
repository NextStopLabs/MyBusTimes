const SHOW_GAME_CONFIG_ON_START = false;

utils.game = {
    
    showDebug: false,
    enemies: [],

    /**
     * Called when the game is initialised: this is similar
     * to Awake() in Unity.
     * 
     * @param {*} context The scene passed in
     */
    onGamePreload: (context) => 
    {
        //Load external plugins
        context.load.plugin('rexshockwavepipelineplugin', 'https://raw.githubusercontent.com/rexrainbow/phaser3-rex-notes/master/dist/rexshockwavepipelineplugin.min.js', true);  
        context.load.plugin('rexhorrifipipelineplugin', 'https://raw.githubusercontent.com/rexrainbow/phaser3-rex-notes/master/dist/rexhorrifipipelineplugin.min.js', true); 

        //This is done because of CORS. Basically, your browser won't let phaser load images
        //from a file:// protocol, so here we must load them externally. You can alternatively
        //host this via a web server to remove this requirement.
        let basePath = "https://staffsunigames.github.io/ohd-editor/game/";

        utils.game.loadCharacterSprites(context, basePath + "assets/Character");
        utils.game.loadEnemySprites(context, basePath + "assets/Enemy");
        utils.game.loadVFXSprites(context, basePath + "assets/FX");
        tilemap.preloadTiles(context, basePath + "assets/TileSet");
    },

    /**
     * Whether or not the sprite given is in the kill zone. 
     * 
     * @param {*} sprite 
     * @returns True/false
     */
    inKillZone: (sprite) => 
    {
        if(!sprite)
            return false;
        
        return sprite.y > 1350;
    },

    hasWon: false,

    checkWinCondition: () =>
    {
        if(!utils.game.exit)
            return false;
        
        if(Phaser.Math.Distance.Between(player.x, player.y, utils.game.exit.x, utils.game.exit.y) < 30)
        {
            if((player.y - utils.game.exit.y) < 20 && !utils.game.hasWon)
            {
                utils.game.hasWon = true;
                onPlayerWinGame();
            }
        }
    },

    updateScoreText: () =>
    {
        if(!utils.game.scoreCounter)
            return;

        const pos = player.scene.cameras.main.getWorldPoint(50, 50);
        utils.game.scoreCounter.setPosition(pos.x, pos.y);
        utils.game.scoreCounter.text = `Score: ${pValues.score}`;
    },

    /**
     * Called when the game is updated: this is similar to
     * Update() in Unity.
     * 
     * @param {*} scene The scene
     */
    onGameUpdate: (scene) =>
    {
        //Check if player is in kill zone
        if(utils.game.inKillZone(player))
            playerUtils.resetPlayer();

        //Clamp player velocity if needed
        playerUtils.clampToTerminalVelocity();

        //Update score text
        utils.game.updateScoreText();

        //Check win condition
        utils.game.checkWinCondition();

        if(!(pValues.lastPos.x == 0 || pValues.lastPos.y == 0))
        {
            //Add to pValues.distTravelled
            pValues.distTravelled += Phaser.Math.Distance.Between(player.x, player.y, pValues.lastPos.x, pValues.lastPos.y);
        }

        if(pValues.distTravelled > 300 && utils.game.controlsTexts.length > 0)
        {
            for(let text of utils.game.controlsTexts)
            {
                text.destroy();
            }

            utils.game.controlsTexts = [];
        }
        
        pValues.lastPos = { x: player.x, y: player.y }

        //Show healthbar
        utils.game.drawHealthBar(player.x, player.y - 10, pValues.hp / playerSettings.maxHealth);

        //Health regeneration
        pValues.hp = Math.min(pValues.hp + playerSettings.healthRegen, playerSettings.maxHealth);
        
        if(pValues.lastYVelocity > 100 && player.body.velocity.y == 0 && player.body.blocked.down)
        {
            //Play VFX: player hit platform
            let effect = vfx.spawnEffect("smokePuff", player.x, player.y+9, 1, 1.25);
            vfx.tintColorDelay(effect, 0xffffff, 500);
        }

        //Are we moving left or right, or trying to?
        if(input.moveLeft() || input.moveRight())
        {
            //Time scale parameters for run speed
            const minTimeScale = 0.75;
            const timeScaleMult = 0.75;

            //Set timescale depending on percentage of max acceleration
            player.anims.timeScale = minTimeScale + (Math.abs(pValues.xAccel) / playerSettings.moveSpeed) * timeScaleMult;
        }
        else
        {
            //Otherwise: they're not running, set it back to 1
            player.anims.timeScale = 1;
        }
        
        //---------------

        //Not attacking? Reset some values
        if(!input.attack())
        {
            //Were they attacking? If so, reset x velocity
            if(pValues.attackAnimTicks > 0)
                pValues.xAccel = 0;

            //Reset amount of ticks fired
            pValues.attackAnimTicks = 0;

            //Reset origin
            player.body.offset.x = 19;
        }

        //---------------

        //Are we grounded?
        const grounded = player.body.blocked.down;

        //If not grounded: decrement coyote time, otherwise, set to max
        if(!grounded)
            pValues.coyoteTime--;
        else
            pValues.coyoteTime = playerSettings.maxCoyoteTime;

        //----------------

        //Is the player moving left, and we're not flipped? 
        if(player.body.velocity.x < 0 && !player.flipX)
            player.flipX = true;

        //The same, but for moving right?
        else if(player.body.velocity.x > 0 && player.flipX)
            player.flipX = false; 

        //-----------------

        // const sgn = (x) => x <= 0;

        // if(sgn(player.body.velocity.y) != sgn(pValues.lastYVelocity) && pValues.coyoteTime < 0)
        // {
        //     playerUtils.doBackflip();
        // }

        // console.log(player.body.velocity.y, pValues.lastYVelocity);
        pValues.lastYVelocity = player.body.velocity.y;
    },

    addEnemy: (x, y) =>
    {
        let enemy = new Enemy(player.scene, x, y);

        utils.game.enemies.push(enemy);
    },

    updateEnemies: () =>
    {
        for(let enemy of utils.game.enemies)
            enemy.update();
    },

    createExit: (x, y) =>
    {
        utils.game.exit = player.scene.add.sprite(x, y, "exit");
        utils.game.exit.setScale(2).setDepth(-1);
    },

    lightning: () =>
    {        
        const originalSettings = {
            bloomIntensity: utils.game.horrifi.bloomIntensity,
            bloomRadius: utils.game.horrifi.bloomRadius,
            bloomThreshold: utils.game.horrifi.bloomThreshold,
            bloomTexelHeight: utils.game.horrifi.bloomTexelHeight,
            bloomTexelWidth: utils.game.horrifi.bloomTexelWidth,
        }

        if (utils.game.lightningEnabled)
        {
            utils.game.horrifi.bloomThreshold = 0.0;
            utils.game.horrifi.bloomRadius = 0.0;
            utils.game.horrifi.bloomIntensity = 4.0;
            
            setTimeout(() => {
                
                utils.game.horrifi.bloomThreshold = originalSettings.bloomThreshold;
                utils.game.horrifi.bloomRadius = originalSettings.bloomRadius;
                utils.game.horrifi.bloomIntensity = originalSettings.bloomIntensity;

            }, 100 + Math.random() * 100)
        }

        setTimeout(utils.game.lightning, 10000 + Math.random() * 5000);
    },

    setupTextElements: (scene) =>
    {
        //This seems stupid, but it works. Create
        //a dummy text object to kick phaser into gear
        //and load the font properly for second time usage
        //
        //Without this, phaser will just use the default font, which sucks
        //
        scene.add.text(-100, -100, "abc", { fontFamily: "Alagard" });

        utils.game.controlsTexts = [];
        
        const style = { fontFamily: "Alagard", fontSize: 24, color: "#b6b8bb" };
        const style2 = { fontFamily: "Alagard", fontSize: 16, color: "#b6b8bb" };

        setTimeout(() => 
        {
            utils.game.controlsTexts.push(scene.add.text(150, 900, "Controls", style));
            utils.game.controlsTexts.push(scene.add.text(150, 935, "A/D - Movement", style2));
            utils.game.controlsTexts.push(scene.add.text(150, 955, "W/Space - Jump", style2));
            utils.game.controlsTexts.push(scene.add.text(150, 975, "E - Fire", style2));

            for(let text of utils.game.controlsTexts)
                text.setDepth(-1);

            //Score counter
            utils.game.scoreCounter = scene.add.text(0, 0, "Score: 0", { ...style, color: "#ffffff" }).setDepth(10);

        }, 200);


        
    },

    /**
     * Called when the game is first created: this is similar
     * to Start() in Unity.
     * 
     * @param {*} context The scene passed in
     */
    onGameCreate: (context) => 
    {
        //Assign plugin things
        utils.game.shockwavePlugin = context.plugins.get('rexshockwavepipelineplugin');
        utils.game.shockwave = utils.game.shockwavePlugin.add(context.cameras.main, { waveRadius: 0, waveWidth: 0 });
        //--
        utils.game.horrifiPlugin = context.plugins.get("rexhorrifipipelineplugin");
        utils.game.horrifi = utils.game.horrifiPlugin.add(context.cameras.main, 
        {
            enable: true,
            // Bloom
            bloomEnable: true,
            bloomRadius: 0.3, bloomIntensity: 1.0, bloomThreshold: 0.8,
            bloomTexelWidth: 0.2, bloomTexelHeight: 0.2,

            // Chromatic abberation
            chromaticEnable: false,
            chabIntensity: 0.01,

            // Vignette
            vignetteEnable: true,
            vignetteStrength: 1, vignetteIntensity: 0.1,

            // Noise
            noiseEnable: false,
            noiseStrength: 0,
            noiseSeed: 0,

            // VHS
            vhsEnable: true,
            vhsStrength: 0.0,

            // Scanlines
            scanlinesEnable: true,
            scanStrength: 0,

            // CRT
            crtEnable: false,
            crtWidth: 0, crtHeight: 0,
        });

        //Css filter
        // game.canvas.style.filter = "hue-rotate(340deg) contrast(1.05)"

        //Output debug stuff
        utils.debug.printResult("Game created.");

        //Resize so it's pixel perfect and setup auto resize
        utils.resizeGameWindow(0.75);
        utils.setupAutoResize(0.75);

        if(SHOW_GAME_CONFIG_ON_START)
        {
            //Show config if needed
            utils.debug.group("- Game config");
            utils.debug.print(`Resolution: (${gameConfig.canvas.width} x ${gameConfig.canvas.height})`);
            utils.debug.print(`Canvas container: #${gameConfig.canvas.parent}`);
            utils.debug.print(`Zoom: ${gameConfig.rendering.zoom}`);
            utils.debug.print(`Gravity: ${gameConfig.physics.arcade.gravity.y}`);
            utils.debug.groupEnd();
        }

        //Load / create needed things
        utils.game.loadCharacterAnims(context);
        utils.game.loadVFXAnims(context);
        utils.game.loadEnemyAnims(context);
        tilemap.createTiles(context);

        //Create text-based elements
        utils.game.setupTextElements(context);
        
        let particles = context.add.particles("square");
        utils.game.rainEffect = particles.createEmitter({
            x: 0,
            y: 0,
            width: game.config.width,
            angle: 0,
            // scale: { start: 0.5, end: 1 },
            scaleY: { start: 1.0, end: 4.0 },
            speedX: { start: -10, end: -100 },
            speedY: { start: 800, end: 1000 },
            alpha: { start: 0.1, end: 0.12 },
            rotate: 0,
            lifespan: 2500,
            maxParticles: 4000,
            emitZone: {
                type: "random",
                source: new Phaser.Geom.Line(0, 0, 1400, 0),
                quantity: 4000
            }
        });

        utils.game.rainEffect.visible = false;

        //Create required objects
        playerUtils.createPlayer(context, 50, 50);

        //Create new group
        utils.game.enemyGroup = context.add.group();

        //Set up input
        input.setupWASD(context);

        //Call lightning initially
        utils.game.lightningEnabled = false;
        utils.game.lightning();

    },

    setFilter: (filter) =>
    {
        game.canvas.style.filter = filter;
    },

    enableLightningFX: () =>
    {
        utils.game.lightningEnabled = true;
    },

    enableRainFX: () =>
    {
        utils.game.rainEffect.visible = true;
    },

    /**
     * Generates a frame dimensions object from width/height.
     * 
     * @param {*} w The width
     * @param {*} h The height
     * @returns A frame dimensions object (obj w/ {height: y, width: x})
     */
    frameWH: (w, h) => { return { frameWidth: w, frameHeight: h }},


    /**
     * Loads all required character sprites, given a scene and base path
     * 
     * @param {*} scene The scene
     * @param {*} basePath The base path
     */
    loadCharacterSprites: (scene, basePath) => 
    {
        scene.load.spritesheet("charIdle", `${basePath}/idleMk2.png`,    utils.game.frameWH(48, 48));
        scene.load.spritesheet("charAtk",  `${basePath}/attack1Mk2.png`, utils.game.frameWH(80, 48));
        scene.load.spritesheet("charJump", `${basePath}/jumpMk2.png`,    utils.game.frameWH(48, 48));
        scene.load.spritesheet("charRun",  `${basePath}/RunMk2.png`,     utils.game.frameWH(48, 48));
        utils.debug.printResult("Character sprites loaded", utils.game.showDebug);
    },
    

    /**
     * Loads all required enemy sprites, given a scene and base path
     * 
     * @param {*} scene The scene
     * @param {*} basePath The base path
     */
    loadEnemySprites: (scene, basePath) => {
        scene.load.spritesheet("enemyAtk", `${basePath}/SkullAttackMk2.png`, utils.game.frameWH(64, 64));
        scene.load.spritesheet("enemyDie", `${basePath}/SkullDieMk2.png`, utils.game.frameWH(64, 64));
        scene.load.spritesheet("enemyMove", `${basePath}/SkullMoveMk2.png`, utils.game.frameWH(64, 64));
        utils.debug.printResult("Enemy sprites loaded", utils.game.showDebug);
    },


    /**
     * Loads all required VFX sprites, given a scene and base path
     * 
     * @param {*} scene The scene
     * @param {*} basePath The base path
     */
    loadVFXSprites: (scene, basePath) => 
    {
        scene.load.spritesheet("bullet",    `${basePath}/bullets.png`, utils.game.frameWH(32, 32));
        scene.load.spritesheet("explosion", `${basePath}/explosionMk2.png`, utils.game.frameWH(32, 32));
        scene.load.spritesheet("smokePuff", `${basePath}/JumpLandFXMk2.png`, utils.game.frameWH(32, 32));
        scene.load.spritesheet("square", `${basePath}/streak.png`, utils.game.frameWH(2, 10));
        utils.debug.printResult("VFX sprites loaded", utils.game.showDebug);
    },

    showCoinsLayer: () =>
    {
        layers.coins.visible = true;
    },


    /**
     * Draws a health bar, given an x, y and percent
     * @param {*} x The x position to draw at
     * @param {*} y The y position to draw at
     * @param {*} percent The percentage to draw
     */
    drawHealthBar: (x, y, percent) => 
    {
        if(typeof utils.hpBarGFX == "undefined")
        {
            utils.hpBarGFX = player.scene.add.graphics();
            utils.hpBarGFX.setDepth(100);
        }

        const graphics = utils.hpBarGFX;
        graphics.x = x;
        graphics.y = y;

        graphics.clear();
        graphics.fillStyle(0x0, 1);

        let barWidth = 30;
        let barHeight = 6;

        graphics.fillRect(-barWidth / 2, -28, barWidth, barHeight);

        //Lerp from yellow to red
        const gValue = percent * 255;
        graphics.fillStyle(0xff0000 | (gValue << 8));

        let w = percent * barWidth;

        graphics.fillRect(-barWidth / 2 + 1, -28 + 1, w - 2, barHeight - 2);
    },

    
    /**
     * Fires a bullet from (x, y) in the X direction specified by direction.
     * @param {*} x The x position to fire from
     * @param {*} y The y position to fire from
     * @param {*} direction The direction on x to fire from
     */
    fireBullet: (x, y, direction) =>
    {
        //Spawn the bullet
        const bullet = player.scene.physics.add.sprite(x, y, "bullet");
    
        //Function to return -1 or 1 depending on true/false
        const nsgn = (j) => { return (j) ? (-1) : (1) };

        //Set up bullet
        bullet.body.allowGravity = false;
        bullet.body.setVelocityX(playerSettings.bulletSpeed * nsgn(direction));
        bullet.body.setAllowDrag(false);
        bullet.body.setAllowRotation(false);
        bullet.body.setSize(30, 15);
        bullet.play("swirl");
        bullet.flipX = direction;
        bullet.setDebug(false, false);

        //Create ghost effect for bullet
        vfx.ghostEffect(50, 200, 15, "Cubic.easeOut", bullet);

        //Set up collision
        player.scene.physics.add.collider(bullet, [layers.foreground, layers.breakables], (obj1, obj2) =>
        {
            onBulletHit(obj1.x, obj1.y);

            //Destroy the bullet
            obj1.destroy();

            //Has it hit a breakable box?
            if (obj2.layer.name == "breakables") 
            {
                //Hits a box
                // utils.onBulletHitBox(obj2, { x: obj2.x * utils.tileSize, y: obj2.y * utils.tileSize });

                // obj2.tilemap.add
                //Remove the tile
                onBulletHitBreakable(obj2);
            }
        });


        //Set up collision
        player.scene.physics.add.collider(bullet, utils.game.enemyGroup, (obj1, obj2) => 
        {
            //TODO: make this code better, it is GRIM at the moment
            //..

            if(!obj2)
                return;

            let index = utils.game.enemies.findIndex(x => x.container == obj2);

            if(index <= -1)
                return;

            let enemy = utils.game.enemies[index];
            enemy.hp = Math.max(enemy.hp - playerSettings.attackDamage, 0.0);

            const x = enemy.container.x + enemy.sprite.x;
            const y = enemy.container.y + enemy.sprite.y;

            if(enemy.hp <= 0)
            {
                if(enemy.attackTimer)
                {
                    player.scene.time.removeEvent(enemy.attackTimer);
                    enemy.attackTimer.remove();
                }

                
                utils.game.enemies.splice(index, 1);
                utils.game.enemyGroup.remove(obj2);

                //Shockwave effect
                onBulletHitEnemy(x, y, obj1, enemy, true);
                // vfx.cameraShake(750, 0.02);

                obj2.destroy();
            }
            else
            {
                if(player.x > x && enemy.curDirection < 0)
                    enemy.flip();

                else if(player.x < x && enemy.curDirection > 0)
                    enemy.flip();

                onBulletHitEnemy(x, y, obj1, enemy, false);
            }

            
            obj1.destroy();
        });
    },

    addCoinAt: (x, y, type) =>
    {
        const coins = [63, 55, 62, 56];
        type = Math.min(Math.max(type, 0), coins.length-1);

        layers.coins.putTileAtWorldXY(coins[type], x, y);
    },

    addBreakableAt: (x, y, type) =>
    {
        type = 51 - type;
        type = Math.min(Math.max(type, 50), 51);
        layers.breakables.putTileAtWorldXY(type, x, y);
    },

    /**
     * Moves the coins layer up and down
     * 
     * @param {*} freq Frequency of sine wave
     * @param {*} magnitude Magnitude of sine wave
     */
    moveCoins: (freq, magnitude) =>
    {
        layers.coins.y = Math.sin(game.getTime() * (freq/100)) * magnitude;
    },

    /**
     * Loads all enemy animations, given a scene and frame rate multiplier.
     * 
     * @param {*} scene The scene
     * @param {*} frameRateMul The frame rate multiplier
     */
    loadEnemyAnims: (scene, frameRateMul = 1) => {
        //Small function for syntactic sugar
        const frameRate = (x) => x * frameRateMul;

        //Create all animations in turn
        scene.anims.create({
            key: "enemyWalk",
            frames: scene.anims.generateFrameNumbers("enemyMove"),
            frameRate: frameRate(12),
            repeat: -1
        });

        scene.anims.create({
            key: "enemyAttack",
            frames: scene.anims.generateFrameNumbers("enemyAtk"),
            frameRate: frameRate(12),
            repeat: -1
        });

        scene.anims.create({
            key: "enemyDie",
            frames: scene.anims.generateFrameNumbers("enemyDie"),
            frameRate: frameRate(12),
            repeat: 0
        });

        utils.debug.printResult("Created enemy animations", utils.game.showDebug);
    },

    /**
     * Loads all vfx animations, given a scene and frame rate multiplier.
     * 
     * @param {*} scene The scene
     * @param {*} frameRateMul The frame rate multiplier
     */
    loadVFXAnims: (scene, frameRateMul = 1) => 
    {
        //Small function for syntactic sugar
        const frameRate = (x) => x * frameRateMul;

        //Create all animations in turn
        scene.anims.create({
            key: "swirl",
            frames: scene.anims.generateFrameNumbers("bullet"),
            frameRate: frameRate(24),
            repeat: -1
        });

        scene.anims.create({
            key: "explosion",
            frames: scene.anims.generateFrameNumbers("explosion"),
            frameRate: frameRate(12),
            repeat: 0
        });

        scene.anims.create({
            key: "smokePuff",
            frames: scene.anims.generateFrameNumbers("smokePuff"),
            frameRate: frameRate(12),
            repeat: 0
        });

        utils.debug.printResult("Created vfx animations", utils.game.showDebug);
    },

    /**
     * Loads all character animations, given a scene and frame rate multiplier.
     * 
     * @param {*} scene The scene
     * @param {*} frameRateMul The frame rate multiplier
     */    
    loadCharacterAnims: (scene, frameRateMul = 1) =>
    {
        //Small function for syntactic sugar
        const frameRate = (x) => x * frameRateMul;
        
        //Create all animations in turn
        scene.anims.create({
            key: "idle",
            frames: scene.anims.generateFrameNumbers("charIdle"),
            frameRate: frameRate(12),
            repeat: -1
        });

        scene.anims.create({
            key: "run",
            frames: scene.anims.generateFrameNumbers("charRun"),
            frameRate: frameRate(12),
            repeat: -1
        });

        scene.anims.create({
            key: "jump",
            frames: scene.anims.generateFrameNumbers("charJump"),
            frameRate: frameRate(12),
            repeat: -1
        });

        scene.anims.create({
            key: "attack",
            frames: scene.anims.generateFrameNumbers("charAtk"),
            frameRate: frameRate(24),
            repeat: -1
        });

        utils.debug.printResult("Created character animations", utils.game.showDebug);
    }

}