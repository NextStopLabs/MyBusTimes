const utils = {

};


/**
 * Returns a random number in range (-x, x), given x
 * 
 * @param {*} x The range
 * @returns A random number in [-x, x]
 */
utils.rnd = (x) => -x + (Math.random() * (x * 2));


/**
 * Resizes the game window
 * 
 * @param {*} scaleFactor 
 * @param {*} width 
 * @param {*} height 
 */
utils.resizeGameWindow = (scaleFactor = 1, width = null, height = null) =>
{
    //Get width and height
    width  = width  || Math.floor(game?.canvas.clientWidth  * scaleFactor);
    height = height || Math.floor(game?.canvas.clientHeight * scaleFactor);

    //Set game
    game?.scale.setGameSize(width, height);
}


/**
 * Sets up auto resize functionality
 * 
 * @param {*} scaleFactor 
 */
utils.setupAutoResize = (scaleFactor) =>
{
    window.onresize = () => utils.resizeGameWindow(scaleFactor);
}


/**
 * Converts a point from world to canvas space
 * 
 * @param {*} x 
 * @param {*} y 
 * @param {*} camera 
 * @returns 
 */
utils.getRelativePositionToCanvas = (x, y, camera) => 
{
    return {
        x: (x - camera.worldView.x) * camera.zoom,
        y: (y - camera.worldView.y) * camera.zoom
    }
}
