/**
 * Enemy settings 
 */
const enemySettings = {
    enemySpeed: 100,
    enemyHP: 100,
    attackFrequency: 200,
    attackDamage: 15.0,
    attackRangeY: 10,
    attackRangeX: 100,
    colliderX: 55,
    bodyWidth: 40
};


/**
 * Player settings that control movement
 */
const playerSettings =
{
    //-- Physics -- 
    bounceFactor: 0.0,
    gravity: 900.0,
    maxSpeed: 1000.0,
    bulletSpeed: 500.0,
    terminalYVelocity: 500.0,
    attackDamage: 25.0,

    //-- Movement -- 
    moveSpeed: 350,
    moveSpeedAir: 200,
    accelRate: 10,
    accelRateAir: 12,

    //-- Jumps --
    jumpSpeed: 10000,
    maxAirJumps: 10,
    maxCoyoteTime: 10,

    //-- Camera --
    lerpSpeed: 0.15,

    //-- Health --
    maxHealth: 100.0,
    healthRegen: 0.2
}

/**
 * Player values
 */
const pValues = {
    xAccel: 0,
    lastDir: 0,
    airJumpsLeft: playerSettings.maxAirJumps,
    coyoteTime: playerSettings.maxCoyoteTime,
    lastYVelocity: 0,
    attackAnimTicks: 0,
    hp: playerSettings.maxHealth,
    distTravelled: 0,
    lastPos: { x: 0, y: 0 },
    score: 0
}


const playerConfig = {
    startPosition: {
        x: 116,
        y: 1145
    }
}

const game = gameConfig.createGame({
    preload: onGamePreload,
    update: onGameUpdate,
    create: onGameCreate
});

function onPlayerCoinCollect(tile, x, y)
{
    //Give score to the player depending on what coin type it is
    if (tile.index > 60)
        pValues.score += (5 * (tile.index - 60));

    //If it's a fancy coin, give 25 score
    else if (tile.index == 55)
        pValues.score += 25;

    //Destroy the coin, removing it from the environment
    playerUtils.destroyCoin(tile);
    
    //Spawns an explosion at the player's position. Here -4 means "behind the player and coin"
    vfx.spawnEffect("explosion", player.x, player.y, -4, 0.75);
}

function onPlayerDamaged(damage)
{
    //Damages the player by damage
    playerUtils.damagePlayer(damage);
    //Generate a random number between (-10, 10)
    const rnd = () => utils.rnd(10);

    //Spawn an effect at the player's pos + this offset
    let explosion = vfx.spawnEffect("explosion", player.x + rnd(), player.y + rnd());

    //Tint it white, provide some camera shake
    vfx.tintColorDelay(explosion, vfx.colors.WHITE, 100);
    vfx.cameraShake(50, 0.01);

    //Ghost the player's sprite, and tint them red
    vfx.ghostEffect(1000, 300, 1, "Expo.easeIn", this.sprite, "ADD");
    vfx.tintColorDelay(player, vfx.colors.RED, 100);

    //Show VHS glitch effect
    vfx.glitchEffect(200);
}

function onPlayerAttack()
{
    //This fires a bullet in whatever direction the player is facing
    utils.game.fireBullet(player.x, player.y, player.flipX);
}

function onBulletHitBreakable(breakable)
{
    //This code removes the tile and destroys it
    breakable.tilemap.removeTile(breakable);
    breakable.destroy()
}

function onBulletHit(x, y)
{
    //Shake the camera
    vfx.cameraShake(200, 0.01);

    //Create an explosion and make it white for 200ms
    const effect = vfx.spawnEffect("explosion", x, y, 0, 1.5);
    vfx.tintColorDelay(effect, 0xffffff, 200);
}

function onPlayerWinGame()
{
    //Show a pop up 
    //alert("You won!");

    //Put the player back at the start
    //playerUtils.resetPlayer();
    
    
    vfx.shockwaveEffect(player.x, player.y, 750, 180);
    playerUtils.doBackflip(1750);
    //window.location.href = "https://images.pond5.com/you-win-footage-170570131_iconl.jpeg"
}

function onBulletHitEnemy(x, y, bullet, enemy, dead)
{
    //Create a puff of smoke and explosion behind the player
    var puff = vfx.spawnEffect("smokePuff", player.x, player.y - 2, -4, 1.5);
    var puff2 = vfx.spawnEffect("explosion", player.x, player.y, -4, 0.5);

    //Tint them both
    vfx.tintColorDelay(puff, vfx.colors.WHITE, 500);
    vfx.tintColorDelay(puff2, 0xf5f2a4, 500);

    //And add a slight bit of camera shake
    vfx.cameraShake(100, 0.005);
    
    if(dead)
    {
        //Enemy has died, create an explosion and tint it to white
        let explosion = vfx.spawnEffect("explosion", x, y, 1, 1.5);
        vfx.tintColorDelay(explosion, 0xffffff, 200);

        //Do some camera shake and make a shockwave
        vfx.cameraShake(250, 0.02);
        vfx.shockwaveEffect(enemy.x, enemy.y, 750, 180);
    }
    else
    {
        //Not dead, create an explosion above them, tint it, do cam shake
        let explosion1 = vfx.spawnEffect("explosion", x, y, 1, 1.15);
        vfx.tintColorDelay(explosion1, 0xffffff, 200);
        vfx.cameraShake(200, 0.01);

        //Tint enemy to red
        vfx.tintColorDelay(enemy.sprite, 0xff0000, 100);

        //Make another explosion where the bullet was
        let explosion2 = vfx.spawnEffect("explosion", bullet.x, bullet.y, 1, 1.0);
        vfx.tintColorDelay(explosion2, 0xffffff, 200);
    }
}

function onPlayerJump(type, grounded)
{
    if(type == "first" || grounded)
    {
        vfx.ghostEffect(1000, 300, 1, 'Sine.easeIn');
    }
    else if(type == "coyote")
    {
        vfx.ghostEffect(1000, 300, 1, 'Sine.easeIn');
    }
    else if(type == "airjump")
    {
        //Tint player white and do a backflip
        vfx.tintColorDelay(player, vfx.colors.WHITE, 200);
        playerUtils.doBackflip(750);

        //Do effects
        vfx.ghostEffect(1000, 800, 1, 'Sine.easeIn');
        vfx.ghostEffect(75, 700, 6, 'Sine.easeOut');

        //Shockwave effect
        vfx.shockwaveEffect(player.x, player.y, 750, 150);

        //Make explosion + camera shake
        const effect = vfx.spawnEffect("explosion", player.x, player.y, 0, 2);
        vfx.tintColorDelay(effect, 0xffffff, 300);
        vfx.cameraShake(200, 0.005);
    }
}

function getRandomInt(max) {
  return Math.floor(Math.random() * max);
}

function onGameUpdate()
{
    utils.game.onGameUpdate(this);
    
    if (getRandomInt(500) === 10)
        vfx.cameraShake(1000, 1);
 
    
    //Jump
    if(input.jump())
        playerUtils.jump();

    //Movement
    if(input.moveLeft()) playerUtils.move(-1);
    else if (input.moveRight()) playerUtils.move(1);
    else playerUtils.move(0);
    
    //If the player has pressed E, call the attack function.
    if(input.attack())
        playerUtils.attack();
        
    //Moves the coins up and down
    utils.game.moveCoins(1.0, 4.0);
    
    utils.game.updateEnemies();
}

function onGamePreload() 
{
    utils.game.onGamePreload(this);
}

function onGameCreate()
{
    //Tells the game systems that the game has been made
    utils.game.onGameCreate(this);

    //This sets the player's position to the default position, and makes the 
    //camera follow them
    player.setPosition(playerConfig.startPosition.x, playerConfig.startPosition.y);
    playerUtils.setCameraFollowPlayer();
    
    //Adds a few boxes
    utils.game.addBreakableAt(347, 1080, 1);
    utils.game.addBreakableAt(347, 1060, 1);
    utils.game.addBreakableAt(347, 1040, 1);
    
    //Shows the default coins made for the level
    utils.game.showCoinsLayer();
    
    //Add a coin
    utils.game.addCoinAt(347, 1020, 2);
    
    //Add default enemies
    utils.game.addEnemy(1099, 200);
    utils.game.addEnemy(486, 163);
    utils.game.addEnemy(1342, 656);
    utils.game.addEnemy(871, 1040);
    utils.game.addEnemy(54, 460);
    
    //Creates an exit at the end of the level
    utils.game.createExit(1391, 64);
    
    //Changes the palette slightly and adds a little contrast
    utils.game.setFilter("hue-rotate(340deg) contrast(1.1)");

    //Enables rain + lightning vfx
    utils.game.enableRainFX();
    utils.game.enableLightningFX();
}