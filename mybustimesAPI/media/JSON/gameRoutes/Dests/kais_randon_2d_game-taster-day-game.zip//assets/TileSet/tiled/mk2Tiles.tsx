<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="mk2Tiles" tilewidth="16" tileheight="16" tilecount="77" columns="7">
 <image source="../tilesetMk2.png" width="112" height="176"/>
</tileset>
