const vfx = { 

}

/**
 * Colours for visual effects
 */
vfx.colors = 
{
    RED:  0xff0000,
    GREEN: 0x00ff00,
    BLUE:  0x0000ff,
    WHITE: 0xffffff,
    BLACK: 0x000000
}

/**
 * Creates a particle system, for use by vfx.prototype.ghostEffect(...)
 * 
 * @param {*} ease Easing function
 * @returns Particle system
 */
vfx.createParticleSystem = (target, ease, lifetime = 500, blendMode = "ADD") => 
{
    //Add it to the scene
    let tempParticles = player.scene.add.particles(target.frame.texture.key);

    //Create an emitter
    tempParticles.createEmitter({
        x: target.x,
        y: target.y,
        scaleX: target.flipX ? (-1) : (1),
        lifespan: lifetime,
        frequency: 90000,
        accelerationX: 0,
        blendMode: blendMode,
        alpha: { start: 1, end: 0.0, ease: ease }
    });

    //Return temp particles
    return tempParticles;
}


/**
 * Shakes the camera temporarily
 * @param {*} duration The duration
 * @param {*} magnitude The magnitude
 * @returns Nothing
 */
vfx.cameraShake = (duration, magnitude) => player.scene.cameras.main.shakeEffect.start(duration, magnitude);


/**
 * Creates an effect which creates a ghost trail
 * of the targets's current sprite.
 * 
 * @param {*} delay The delay between ghost frames
 * @param {*} lifetime How long each ghost frame should stay
 * @param {*} repeat How many ghost frames should be spawned
 * @param {*} ease The easing for fading out over time
 */
vfx.ghostEffect = (delay = 500, lifetime = 500, repeat = 5, ease = "Expo.easeOut", target = null, blendMode = "ADD") => 
{
    if (target == null)
        target = player;

    //Get the scene
    const scene = player.scene;


    //Temp particle system array
    let particles = [];

    //Count of particles
    let i = 0;

    //Create first particle system
    particles.push(vfx.createParticleSystem(target, ease, lifetime, blendMode));

    //Set up interval every {delay} ms
    let interval = window.setInterval(() => {
        //Exceeded particle amount? die
        if (++i >= repeat)
            clearInterval(interval);

        else if (target == null) {
            clearInterval(interval);

            //Destroy all particles
            for (let i = 0; i < particles.length; i++)
                particles[i].destroy();

        }

        //Otherwise add them to the list
        else
            particles.push(vfx.createParticleSystem(target, ease, lifetime, blendMode));

    }, delay);

    //Wait for delay: destroy
    window.setTimeout(function () 
    {
        //Clear the timer
        clearInterval(interval);

        //Destroy all particles
        for (let i = 0; i < particles.length; i++)
            particles[i]?.destroy();

    }, (repeat * lifetime) + 10);
}


/**
 * Creates the effect specified by key at the given position
 * 
 * @param {*} key The effect key; must be the same as animation
 * @param {*} x The x pos
 * @param {*} y The y pos
 */
vfx.spawnEffect = (key, x=player.x, y=player.y, depth = 0, scale=1) =>
{
    const effect = player.scene.add.sprite(x, y, key);
    effect.play(key, false);
    effect.setOrigin(0.5, 0.5);
    effect.setDepth(depth);
    effect.setScale(scale);

    effect.once('animationcomplete', () => effect.destroy());

    return effect;
}

vfx.glitchEffect = (duration=100) =>
{
    //Plugin not loaded? Do nothing
    if(!utils.game.horrifi)
        return;


    //Ease out vhs strength
    //..
    
    player.scene.tweens.add
    ({
        targets: utils.game.horrifi,
        props: {
            vhsStrength: {
                from: 1.0,
                to: 0.0
            }
        },
        duration: duration,
        ease: "Expo.easeOut"
    })
}

/**
 * 
 * @param {*} x 
 * @param {*} y 
 * @param {*} duration 
 * @param {*} width 
 */
vfx.shockwaveEffect = (x=player.x, y=player.y, duration=750, width=150) =>
{
    //Could load plugin? Do nothing
    if(!utils.game.shockwave)
        return;

    //Get relative position to camera, set centre to player
    const pos = utils.getRelativePositionToCanvas(x, y, player.scene.cameras.main);
    utils.game.shockwave.setCenter(pos.x, pos.y);

    //Tween shockwave object using waveRadius and waveWidth
    player.scene.tweens.add
    ({
        targets: utils.game.shockwave,
        props: 
        {
            //Radius should expand
            waveRadius:
            {
                from: 0,
                to: width
            },

            //Width should contract
            waveWidth:
            {
                from: 100,
                to: 0
            }
        },
        ease: "Expo.easeOut",
        duration: duration
    });
}

/**
 * Tints the target a colour, then clears after "delay" ms.
 * 
 * @param {*} color The colour in hex int format
 * @param {*} delay The delay in ms
 */
vfx.tintColorDelay = (target, color, delay = 200) => 
{
    //Set the tint
    target.setTintFill(color);

    //Clear tint later
    window.setTimeout(() => target.clearTint(), delay);
} 