
const enemySpriteKeys = {
    move: "enemyMove",
    attack: "enemyAtk",
    die: "enemyDie"
};


class Enemy
{
    constructor(scene, x, y)
    {
        this.scene = scene;
        this.sprite = this.addSprite(x, y);
        
        this.frontCollider = null;
        this.container = this.setupContainer(x, y);

        this.curDirection = 1;
        this.attacking = false;
        this.hp = enemySettings.enemyHP;

        this.attackTimer = null;

        utils.game.enemyGroup.add(this.container);

        // this.setupColliders();
    }

    blockedInDir(direction, amount=25)
    {
        const x = this.container.x + this.sprite.x;
        const y = this.container.y + this.sprite.y;

        return layers.foreground.getTileAtWorldXY(x + amount * direction, y) || layers.breakables.getTileAtWorldXY(x + amount * direction, y);
    }

    frontColliderBlocked()
    {
        const x = this.container.x + this.frontCollider.x;
        const y = this.container.y + this.frontCollider.y;

        return layers.foreground.getTileAtWorldXY(this.container.x + this.frontCollider.x, this.container.y + this.frontCollider.y) ||
            layers.breakables.getTileAtWorldXY(this.container.x + this.frontCollider.x, this.container.y + this.frontCollider.y);
    }

    flip()
    {
        this.curDirection = -this.curDirection;
        this.frontCollider.x = (this.curDirection < 0) ? (enemySettings.bodyWidth - enemySettings.colliderX) : (enemySettings.colliderX);
        this.sprite.flipX = !this.sprite.flipX;
    }
    
    update()
    {
        // console.log(this.blockedInDir(this.curDirection));

        if (this.attacking) 
        {
            this.sprite.play("enemyAttack", true);
        }
        else
        {
            this.sprite.play("enemyWalk", true);
        }


        //Apply velocity if grounded
        if (this.container.body.blocked.down && !this.attacking)
            this.container.body.setVelocityX(enemySettings.enemySpeed * this.curDirection);
        else
            this.container.body.setVelocityX(0);

        //Check if blocked in dir, if so, flip
        if(this.container.body.blocked.down && (this.blockedInDir(this.curDirection) || !this.frontColliderBlocked()) && !this.attacking)
        {
            this.flip();
        }

        const oldValue = this.attacking;
        this.attacking = this.updateEnemyAttackLogic();
        
        if(oldValue == true && this.attacking == false)
        {
            if (this.attackTimer) 
            {
                this.attackTimer.remove();
                this.scene.time.removeEvent(this.attackTimer);
            }
        }
        else if(oldValue == false && this.attacking == true)
        {
            this.attackTimer = this.scene.time.addEvent({ delay: enemySettings.attackFrequency, callback: () =>
            {
                onPlayerDamaged(enemySettings.attackDamage);

            }, loop: true });
        }
    }

    tileMarchCheckX(start, end, steps)
    {
        //If steps is invalid, take abs: must be at least one though
        if(steps <= 0)
            steps = Math.max(Math.abs(steps), 1);

        //Get amount to march by increment
        const stepIncrement = (end - start) / steps;

        //X and Y of enemy
        const x = this.container.x + this.sprite.x;
        const y = this.container.y + this.sprite.y;
        
        //This starts at 1 because there is no point checking the current tile
        //that the enemy is on
        for(let i = 0; i < steps; i++)
        {
            //Find x offset for march
            const amount = (start) + stepIncrement * i;

            //Get the tile at this offset: continue if not null
            if (!layers.foreground.getTileAtWorldXY(x + amount, y) && !layers.breakables.getTileAtWorldXY(x + amount, y))
                continue;

            //Otherwise return true
            return true;
        }

        //Otherwise.. we've skipped all, return true
        return false;
    }

    updateEnemyAttackLogic()
    {
        const enemyX = this.container.x + this.sprite.x;
        const enemyY = this.container.y + this.sprite.y;

        //Is player in the same y range?
        if(Math.abs(player.y - enemyY) > enemySettings.attackRangeY)
            return false;

        //Is player in x range?
        if(Math.abs(player.x - enemyX) > enemySettings.attackRangeX)
            return false;

        //We're in range! Let's check LoS
        //..

        const enemyFacingLeft = this.curDirection < 0;
        const playerToLeft = enemyX >= player.x;
        const playerToRight = enemyX < player.x;

        if((enemyFacingLeft && playerToLeft) || (!enemyFacingLeft && playerToRight))
        {
            //They're in the right direction: are there tiles between them?
            // return !this.blockedInDir(this.curDirection, 45);
            return !this.tileMarchCheckX(0, enemySettings.attackRangeX, 4);
        }
        
        return false;
    }

    setupContainer(x, y)
    {
        let circle = this.scene.physics.add.sprite(0, 0, '');

        circle.setScale(0.5, 0.5).setVisible(true);
        circle.body.setAllowGravity(false);
        circle.setVisible(false);

        circle.x = enemySettings.colliderX;
        circle.y = 72;

        this.frontCollider = circle;

        let container = this.scene.add.container(x, y);
        container.add([ this.sprite, circle ]);

        //Reset local pos
        this.sprite.x = 20;
        this.sprite.y = 30;
        
        this.scene.physics.world.enable(container);
        this.scene.physics.add.collider(container, [layers.foreground, layers.breakables]);
        this.scene.physics.add.collider(circle, [layers.foreground, layers.breakables]);

        container.body.setSize(enemySettings.bodyWidth, 64);

        return container;
    }

    addSprite(x, y)
    {
        let sprite = this.scene.add.sprite(x, y, enemySpriteKeys.move);
        sprite.play("enemyWalk");

        return sprite;
    }
}