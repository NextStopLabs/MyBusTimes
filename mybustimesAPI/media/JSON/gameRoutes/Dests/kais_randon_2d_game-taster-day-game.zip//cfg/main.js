
/**
 * Short function to return the window dimensions,
 * given a scale factor
 * 
 * @param {*} scaleFactor The scaling factor
 * @returns The window dimensions
 */
const getWindowDimensions = (scaleFactor) => 
{
    return {
        width:  window.innerHeight * scaleFactor,
        height: window.innerWidth * scaleFactor
    }
};

/**
 * The game config: contains stuff about the
 * canvas, rendering options & physics.
 */
const gameConfig = {
    
    canvas: {
        type: Phaser.WEBGL,
        width: getWindowDimensions(0.5).width,
        height: getWindowDimensions(0.5).height,
        parent: "container" 
    },

    rendering: {
        zoom: 1.0,
        pixelArt: true,
        roundPixels: true,
    },

    physics: {
        default: "arcade",
        arcade: {
            debug: false,
            x: 0,
            y: 0,
            width: 1400,
            height: 1400,
            gravity: {
                y: 200
            }
        }
    },

    scale: {
        // mode: Phaser.Scale.FIT,
        // parent: "container",
        // zoom: 0.5,
        // min: {
        //     width: 800,
        //     height: 600
        // },
        // max: {
        //     width: 1600,
        //     height: 1200
        // }
    }
};


/**
 * Creates the game from a scene config object.
 * 
 * @param {*} sceneConfig The scene config object
 * @returns The Phaser.js game object.
 */
gameConfig.createGame = (sceneConfig) => 
{
    utils.debug.print("Creating new game.");

    //Just make the game
    return new Phaser.Game({
        ...gameConfig.canvas,
        ...gameConfig.rendering,
        physics: { ...gameConfig.physics },
        scale: { ...gameConfig.scale },
        scene: { ...sceneConfig }
    });
}