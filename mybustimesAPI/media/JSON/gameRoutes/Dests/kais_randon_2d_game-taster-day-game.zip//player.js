var player = null;
const playerUtils = {};

/**
 * Whether or not to draw debug overlay
 */
const playerDebug = false;



/**
 * Checks if the player is blocked in a direction, and their
 * X velocity aligns with that blocked direction.
 * 
 * @param {*} colDir The direction of the block for the collider: "left", "right", "up" or "down"
 * @param {*} velDir The X velocity direction: -1 or 1
 * @returns True or false depending on the parameters specified
 */
playerUtils.checkBlockedDir = (colDir, velDir) => 
{
    const amount = 10;
    const blockedLeft = layers.foreground.getTileAtWorldXY(player.x - amount, player.y);
    const blockedRight = layers.foreground.getTileAtWorldXY(player.x + amount, player.y);

    if(colDir == "left")
        return blockedLeft && (velDir == -1);

    else if(colDir == "right")
        return blockedRight && (velDir == 1);

    return player.body.blocked[colDir];
};

playerUtils.damagePlayer = (amount) =>
{
    //Decrement health
    pValues.hp -= amount;

    //If health is less than 0.. call on player death
    //..

    if(pValues.hp <= 0)
    {
        pValues.hp = playerSettings.maxHealth;
        
        playerUtils.resetPlayer();
    }
}


/**
 * Called when the player wants to move left or right in the
 * air. The direction parameter controls whether to move left
 * or right.
 * 
 * @param {*} direction The direction to move in.
 */
playerUtils.moveInAir = (direction) => 
{
    //If the direction is 0, or we've swapped direction:
    if (direction == 0 || direction != pValues.lastDir)
        pValues.xAccel = 0;

    //If we are not quite at full speed, add onto speed
    if (Math.abs(pValues.xAccel) <= playerSettings.moveSpeedAir)
        pValues.xAccel += playerSettings.accelRateAir;

    //Clamp speed just in case
    pValues.xAccel = Math.min(playerSettings.moveSpeedAir, pValues.xAccel);

    //Finally set x velocity & last direction
    player.setVelocityX(direction * pValues.xAccel);
    pValues.lastDir = direction;
}


/**
 * Called when the player wants to move left or right. Here
 * the direction parameter controls whether to move left or
 * right. Movement is applied with acceleration: using 
 * pValues.xAccel.
 * 
 * @param {*} direction The direction to move in.
 * @returns 
 */
playerUtils.move = (direction) =>
{
    //Is the player grounded?
    const grounded = player.body.blocked.down;

    if(input.attack())
    {
        //Player wants to move but is attacking. Flip direction of fire
        //if needed:
        
        if(direction != 0)
            player.flipX = (direction == -1);

        return;
    }

    //Grounded? Play walk or idle if move detected
    if(grounded)
        player.play((direction != 0) ? ("run") : ("idle"), true);
    else
        player.play("jump", true);


    if(playerUtils.checkBlockedDir("right", direction) || playerUtils.checkBlockedDir("left", direction))
    {
        //Check if they're moving right (and blocked right) or 
        //moving left (and blocked left). If so:
        pValues.xAccel = 0;

        //Skip the rest
        return;
    }

    //Not grounded? Apply move in air functionality then
    if(!grounded)
        return playerUtils.moveInAir(direction);

    //If direction is 0 (they're not moving) or direction has changed
    if (direction == 0 || direction != pValues.lastDir)
        pValues.xAccel = 0;

    //If we are not quite at full speed yet, add onto xAccel by the
    //rate specified
    if(Math.abs(pValues.xAccel) <= playerSettings.moveSpeed)
        pValues.xAccel += playerSettings.accelRate;

    //Clamp xAccel to move speed, just in case
    pValues.xAccel = Math.min(playerSettings.moveSpeed, pValues.xAccel);

    //Set the velocity & last direction.
    player.setVelocityX(direction * pValues.xAccel);
    pValues.lastDir = direction;
}


/**
 * Clamps Y velocity of the player to terminal velocity
 */
playerUtils.clampToTerminalVelocity = () => 
{
    //Clamp upper range function, for sgn(x) = 1 and sgn(x) = -1
    // const clampU = (x, b) => (x < 0) ? Math.max(x, b) : Math.min(x, b);

    //Clamp upper range but only when sgn(x) = 1
    const clampU = Math.min;
    
    //Just set the y component to the clamped range
    player.body.setVelocityY(clampU(player.body.velocity.y, playerSettings.terminalYVelocity));
}



/**
 * Resets the player: spawns them back, resets parameters
 */
playerUtils.resetPlayer = () => 
{
    utils.game.hasWon = false;
    
    //Set the player back to spawn position
    player.x = playerConfig.startPosition.x;
    player.y = playerConfig.startPosition.y;

    //Unflip and move camera
    player.flipX = false;
    player.scene.cameras.main.centerOn(player.x, player.y);

    //Change body properties
    player.setRotation(0);
    player.body.setVelocity(0, 0);

    //Reset player values
    pValues.xAccel = 0;
    pValues.lastDir = 1;
    pValues.lastYVelocity = 0;
    pValues.coyoteTime = playerSettings.maxCoyoteTime;
    pValues.airJumpsLeft = playerSettings.maxAirJumps;
    pValues.attackAnimTicks = 0;
}


/**
 * Called when the player needs to attack.
 */
playerUtils.attack = () =>
{
    //Is the player grounded?
    const grounded = player.body.blocked.down;

    //If not, return
    if(!grounded)
        return;

    //Change from bool to sgn(x)
    const flippedXDirL = -player.flipX;
    const flippedXDirR = +!player.flipX;

    //Check if blocked: no point firing if so
    if(playerUtils.checkBlockedDir("left", flippedXDirL) || playerUtils.checkBlockedDir("right", flippedXDirR))
        return;

    //Play attack animation and reset velocity
    player.play("attack", true);
    player.body.offset.x = 35;
    player.setVelocity(0, 0);
    pValues.xAccel = 0;

    //Look at the current frame
    const curFrame = player.anims.currentFrame.textureFrame;

    //Its the start of a new cycle: reset anim ticks
    if(curFrame == 0)
        pValues.attackAnimTicks = 0;

    else if(curFrame == 4 && pValues.attackAnimTicks == 0)
    {
        //Otherwise, if we're on the attack frame, increment ticks
        pValues.attackAnimTicks++;
        onPlayerAttack();
    }
}




/**
 * Called when the user has pressed the jump key. There are two
 * parts to the jump functionality: coyote time and air jumps.
 */
playerUtils.jump = () =>
{
    //Is the player currently grounded?
    const grounded = player.body.blocked.down;

    //Alias, so the actual jump can be changed freely
    const doJump = () => player.setVelocityY(-playerSettings.jumpSpeed);

    if(grounded)
    {
        //They're grounded: deplete coyote time
        pValues.coyoteTime = 0;

        //Set air jumps back to full, and make them jump
        pValues.airJumpsLeft = playerSettings.maxAirJumps;
        doJump();
        onPlayerJump("first", true);
    }
    else
    {
        //Not grounded. Lets see if:
        //- there is coyote time remaining
        //- otherwise, if they have air jumps left
        //..

        if(pValues.coyoteTime > 0)
        {
            //Some coyote time left: deplete it and jump
            pValues.coyoteTime = 0;
            doJump();
            onPlayerJump("coyote", false);
        }

        //Otherwise there are air jumps left: do a jump
        else if((--pValues.airJumpsLeft + 1) > 0)
        {
            doJump();
            onPlayerJump("airjump", false);
        }
    }
}



/**
 * Makes the player backflip
 * @param {*} duration The duration of the backflip
 */
playerUtils.doBackflip = (duration=450) => 
{
    AngleTween = player.scene.tweens.add
    ({
        targets: player,
        angle: 360,
        ease: "Sine.easeOut",
        duration: duration,
    });
}


/**
 * Sets the camera to follow the player
 */
playerUtils.setCameraFollowPlayer = () =>
{
    //Get the scene
    const scene = player.scene;

    //Just centre on the player: set bounds
    scene.cameras.main.centerOn(player.x, player.y);
    scene.cameras.main.setBounds(0, 0, 1432, 1400);
    scene.cameras.main.startFollow(player, true);
    scene.cameras.main.setLerp(playerSettings.lerpSpeed, playerSettings.lerpSpeed);

    //Set player collide with bounds
    player.body.collideWorldBounds = true;
}

playerUtils.destroyCoin = (tile) =>
{
    layers.coins.tilemap.removeTile(tile);
    tile.destroy();
}

/**
 * Called when the player's sprite overlaps with a coin.
 * 
 * @param {*} obj1 
 * @param {*} obj2 
 */
playerUtils.onCoinCollect = (obj1, obj2) =>
{
    //Which tile is the player currently at? We need this so we can delete the coin.
    var tile = layers.coins.getTileAtWorldXY(player.x, player.y);

    //Somehow, if there is no tile, don't continue any further.
    if (tile == null)
        return;
 
    onPlayerCoinCollect(tile, player.x, player.y);


}


/**
 * Creates a player, initialises them, and
 * sets up references.
 * 
 * @param {*} scene The scene
 * @param {*} x The start X pos
 * @param {*} y The start Y pos
 */
playerUtils.createPlayer = (scene, x, y) =>
{
    utils.debug.print("Creating player, scene is: " + scene);

    //Add the sprite
    player = scene.physics.add.sprite(x, y, "charIdle");

    //Set up collider parameters
    player.setBounce(playerSettings.bounceFactor);
    player.setGravityY(playerSettings.gravity);
    player.body.maxSpeed = playerSettings.maxSpeed;

    //Set up colliders
    scene.physics.add.collider(player, [layers.foreground, layers.breakables]);
    //--
    player.body.setAllowRotation(false);
    player.body.setAllowDrag(false);
    player.body.setSize(10, 48);

    //If overlap with coin, call callback
    scene.physics.add.overlap(player, layers.coins, playerUtils.onCoinCollect);

    //Debug enabled?
    player.setDebug(playerDebug, playerDebug, 0xff00ff);

    //Play default idle animation
    player.play("attack");
}