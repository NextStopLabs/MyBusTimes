Hey kai's randon 2d game, thanks for taking part in the taster session on 26/04/2025! We hoped you enjoyed your visit. This zip file contains the game you created from the taster session. To show your family and friends, you need to do just open index.html in a modern web browser (it runs best in Chrome).

If you wish to have another go at our taster session at home, the link can be found at https://staffsunigames.github.io/ohd-editor. You can alternatively make use of an IDE like VSCode to further modify your solution.

Have fun!